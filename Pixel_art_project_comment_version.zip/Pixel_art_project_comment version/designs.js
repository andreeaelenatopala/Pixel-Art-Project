//defining variables
let canvas = document.getElementById("pixelCanvas");
let sizePicker = document.getElementById("sizePicker");
let color = document.getElementById("colorPicker");
let height = document.getElementById("inputHeight");
let width = document.getElementById("inputWidth");

//function for creating the grid with 2 while loops
function makeGrid()
{
  //declaring and initializing the iterators for the 2 loops
  let r=0;
  let c=0;
  while (r<height.value)
  {
    //create a row
    const row = canvas.insertRow(r);
    while (c<width.value)
    {
      //create a cell
      const cell = row.insertCell(c);
      //make the new cell interactive
      makeInteractiveCell (cell);
      //increment the iterator c
      c=c+1;
    }
    r=r+1;
    //reinitialize the iterator c for the new row
    c=0;
  }
}

//function for making a cell interactive
function makeInteractiveCell (cell)
{
  //adding a listener event when user is pressing (click) the mouse on the cell
  cell.addEventListener("click", fill);
}

//function for filling the cell with the color chosen by the user
function fill () {
    this.setAttribute("style", `background-color: ${color.value}`);
}

//function to clear the grid when the user is pressing  the "submit" button after painting the canvas
function clearGrid(){
    if (canvas.firstChild){
         canvas.removeChild(canvas.firstChild);
    }
}
//adding an event when the user wants to chose a color
color.addEventListener("click", function(){});

//function to define the set of instruction that is triggered when clicking on "submit" button
sizePicker.onsubmit = function(event){
    event.preventDefault();
    clearGrid();
    makeGrid();
}
